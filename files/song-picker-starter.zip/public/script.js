const firebaseConfig = {
  apiKey: "AIzaSyC8VZVNB04OpzONcYhH1E2lnYkWsIEnQVo",
  authDomain: "song-picker-app.firebaseapp.com",
  projectId: "song-picker-app",
  storageBucket: "song-picker-app.appspot.com",
  messagingSenderId: "503659015445",
  appId: "1:503659015445:web:62c6557b5043ccf9584d1c"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

const list = document.getElementById("song-list");
db.collection("songs").get().then((querySnapshot) => {
  querySnapshot.forEach((doc) => {
    const song = doc.data();
    const li = document.createElement("li");
    li.textContent = song.title + (song.selected ? " (selected)" : "");
    if (!song.selected) {
      li.style.cursor = "pointer";
      li.onclick = () => {
        window.location.href = `confirm.html?id=${doc.id}`;
      };
    } else {
      li.style.color = "gray";
    }
    list.appendChild(li);
  });
});